package jerad.reyes.com.reyesjeradexam1;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import jerad.reyes.com.reyesjeradexam1.Activity2;
import jerad.reyes.com.reyesjeradexam1.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent i = new Intent(this, Service.class);
        startService(i);
    }

    public void process(View v){
        Intent i=null, chooser=null;
        if(v.getId() == R.id.toscreen){
            i = new Intent(this,Activity2.class);
            startActivity(i);
        }
        else if(v.getId()==R.id.mapbtn){
            i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse("geo://14.6226° N, 121.0005° E"));
            chooser = Intent.createChooser(i, "Choose a Map App");
            startActivity(chooser);
        }
    }
}